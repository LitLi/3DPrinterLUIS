﻿using System;
using System.Threading.Tasks;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Connector;
using System.Configuration;

namespace _3DPrinterBot.Dialogs
{
    [Serializable]
    public class RootDialog : IDialog<object>
    {
        private QnAHelper _helper = null;

        public RootDialog()
        {
            AppSettingsReader reader = new AppSettingsReader();
            string Id = reader.GetValue("KnowledgeBaseId", typeof(string)).ToString();
            string subscriptionKey = reader.GetValue("SubscriptionKey", typeof(string)).ToString();
            _helper = new QnAHelper(Id, subscriptionKey);
        }

        public Task StartAsync(IDialogContext context)
        {
            context.Wait(MessageReceivedAsync);

            return Task.CompletedTask;
        }

        private async Task MessageReceivedAsync(IDialogContext context, IAwaitable<object> result)
        {
            var activity = await result as Activity;
            // return our reply to the user
            string answer = await _helper.GetAnswer(activity.Text);
            activity.Text = answer;
            await context.PostAsync(activity.Text);

            context.Wait(MessageReceivedAsync);
        }
    }
}