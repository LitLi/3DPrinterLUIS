﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace _3DPrinterBot
{
    [JsonObject]
    public class KBQuestion
    {
        [JsonProperty("question")]
        public string Question { get; set; }
    }
}