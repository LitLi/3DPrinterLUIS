﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Threading.Tasks;
using System.Net;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;

namespace _3DPrinterBot
{
    [Serializable]
    public class QnAHelper
    {
        public string KnowledgeBaseId { get; set; }
        public string SubscriptionKey { get; set; }
        public QnAHelper(string Id, string subscriptionKey)
        {
            KnowledgeBaseId = Id;
            SubscriptionKey = subscriptionKey;
        }

        public async Task<string> GetAnswer(string question)
        {
            if (string.IsNullOrEmpty(question))
            {
                return "Invalid question";
            }
            else
            {
                KBQuestion qItem = new KBQuestion();
                qItem.Question = question;
                return await KBPoster(qItem);
            }
        }

        private async Task<string> KBPoster(KBQuestion questionItem)
        {
            HttpClient client = new HttpClient();
            HttpContent content = new StringContent(JsonConvert.SerializeObject(questionItem), Encoding.UTF8, "application/json");
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", SubscriptionKey);
            var result = await client.PostAsync(GetKBUriInternal(KnowledgeBaseId), content);
            var answerJson = await result.Content.ReadAsStringAsync();
            KBAnswer answer = null;
            try
            {
                answer = JsonConvert.DeserializeObject<KBAnswer>(answerJson);
            }
            catch (Exception ex)
            {
                string err = ex.ToString();
            }

            if (null == answer)
                return string.Empty;
            return answer.Answers[0].Answer;
        }

        private string GetKBUriInternal(string KnowledgeBaseId)
        {
            if (string.IsNullOrWhiteSpace(KnowledgeBaseId))
                return string.Empty;
            else
                return string.Format("https://westus.api.cognitive.microsoft.com/qnamaker/v2.0/knowledgebases/{0}/generateAnswer", KnowledgeBaseId);
        }
    }
}