﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _3DPrinterBot
{
    [JsonObject]
    public class KBAnswer
    {
        [JsonProperty("answers")]
        public List<KBAnswerItem> Answers { get; set; }
    }
    [JsonObject]
    public class KBAnswerItem
    {
        [JsonProperty("answer")]
        public string Answer { get; set; }
        [JsonProperty("questions")]
        public List<string> Questions { get; set; }
        [JsonProperty("score")]
        public double Score { get; set; }
    }
}